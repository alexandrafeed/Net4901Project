<h1>About Us</h1>
<p><B>  This is a project for NET4901. We are a group of 4th year Bachelor of Information Technology students majoring in Network Technology.</p>
<p>  We decided to divide the work to two different teams which are the backend development team and web development team.</p>
<p> The backend development team consists of : <ul>
                                               <li>John Mitchell</li>
                                               <li>Syed Taqi Raza</li>
                                               <li>Alex Sol</li>
                                               <li>Logan McDonald </li>
                                              </ul>
The web development team consists of : <ul>
                                        <li>Nnamdi Azubike</li>
                                        <li>Mujtaba Alhabib</li>
                                        <li>Ahmad Nasrallah</li>
                                       </ul>
</B>
</p>
